#!/bin/sh
time ../../../simrun.exe --file spawn0.sim --script script0.txt &> DONE

#../simrun.exe --file Control.sim --script script0.txt
